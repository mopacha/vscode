/*
 * @Descripttion:
 * @version:
 * @Author: liuqinqin
 * @Date: 2020-06-03 14:06:33
 * @LastEditors: liuqinqin
 * @LastEditTime: 2020-06-03 14:11:34
 */
export default {
  BASE_URL: 'https://uplus.sit.hs.net', // 测试环境
  // BASE_URL: 'https://uplus.hundsun.com' // 生产环境
}
