/*
 * @Descripttion: 
 * @version: 
 * @Author: liuqinqin
 * @Date: 2020-05-26 14:56:39
 * @LastEditors: liuqinqin
 * @LastEditTime: 2020-06-11 19:17:17
 */
//app.js
App({
  onLaunch: function () {
    __base__.DEBUG_MODE = true;
  },
  globalData: {
    userInfo: null
  }
})