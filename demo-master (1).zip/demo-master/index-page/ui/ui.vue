
<template>
    <div>
        Hello,World !
    </div>
</template>
<script>
    export default {
        data(){
            return {};
        },
        props:[]
    }
</script>
<style lang="less">
    
</style>
