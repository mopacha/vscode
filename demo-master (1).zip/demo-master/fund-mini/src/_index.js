
    import "../src/app.wxss"
    import config from "../src/app.json"
    require('../src/versionCheck.js')
    App.weappConfig = config;
    require("../src/app.js");
    Page.weappRoute="pages/home/home"
Page.weappPage=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/home/home.wxml");
Component.weappRoute="pages/home/home"
Component.weappComponent=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/home/home.wxml");
require('../src/pages/home/home.wxss');
Page.weappConfig = require('../src/pages/home/home.json');
require('../src/pages/home/home.js');
Page.weappRoute="pages/discover/discover"
Page.weappPage=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/discover/discover.wxml");
Component.weappRoute="pages/discover/discover"
Component.weappComponent=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/discover/discover.wxml");
require('../src/pages/discover/discover.wxss');
Page.weappConfig = require('../src/pages/discover/discover.json');
require('../src/pages/discover/discover.js');
Page.weappRoute="pages/setting/setting"
Page.weappPage=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/setting/setting.wxml");
Component.weappRoute="pages/setting/setting"
Component.weappComponent=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/setting/setting.wxml");
require('../src/pages/setting/setting.wxss');
Page.weappConfig = require('../src/pages/setting/setting.json');
require('../src/pages/setting/setting.js');
Page.weappRoute="pages/fund-list/fund-list"
Page.weappPage=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/fund-list/fund-list.wxml");
Component.weappRoute="pages/fund-list/fund-list"
Component.weappComponent=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/fund-list/fund-list.wxml");
require('../src/pages/fund-list/fund-list.wxss');
Page.weappConfig = require('../src/pages/fund-list/fund-list.json');
require('../src/pages/fund-list/fund-list.js');
Page.weappRoute="pages/fund/fund"
Page.weappPage=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/fund/fund.wxml");
Component.weappRoute="pages/fund/fund"
Component.weappComponent=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/fund/fund.wxml");
require('../src/pages/fund/fund.wxss');
Page.weappConfig = require('../src/pages/fund/fund.json');
require('../src/pages/fund/fund.js');
Page.weappRoute="pages/managerchange/managerchange"
Page.weappPage=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/managerchange/managerchange.wxml");
Component.weappRoute="pages/managerchange/managerchange"
Component.weappComponent=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/managerchange/managerchange.wxml");
require('../src/pages/managerchange/managerchange.wxss');
Page.weappConfig = require('../src/pages/managerchange/managerchange.json');
require('../src/pages/managerchange/managerchange.js');
Page.weappRoute="pages/rule/rule"
Page.weappPage=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/rule/rule.wxml");
Component.weappRoute="pages/rule/rule"
Component.weappComponent=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/rule/rule.wxml");
require('../src/pages/rule/rule.wxss');
Page.weappConfig = require('../src/pages/rule/rule.json');
require('../src/pages/rule/rule.js');
Page.weappRoute="pages/file/file"
Page.weappPage=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/file/file.wxml");
Component.weappRoute="pages/file/file"
Component.weappComponent=require("/home/abel/data/Code/gmulight/github/fund-mini/src/pages/file/file.wxml");
require('../src/pages/file/file.wxss');
Page.weappConfig = require('../src/pages/file/file.json');
require('../src/pages/file/file.js');
