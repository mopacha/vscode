/* 不同环境的参数配置*/
export default {
    appBaseUrl: "http://wx.cjzcgl.cn/appServer/",
    tradePubKey: 'MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJkZuOHsWQ0qPcNlkH7t9aE5qUUxtLjsSZh/6NYe2xG6jbaFwcAN/mYazAVGeWoT95zcGS6c4W2CV+EkQNYC9l0CAwEAAQ==',
}